import AsyncStorage from '@react-native-async-storage/async-storage';
import { Session, UserProfile } from './types';

const ACTIVE_USER_KEY = 'shift_active_user';
const USERS_KEY = 'shift_users';
const SESSIONS_KEY = 'shift_sessions';

export type SessionPayload = {
  sessions: Session[];
  activeSession: Session | null;
};

const getUserMap = async (): Promise<Record<string, UserProfile>> => {
  const raw = await AsyncStorage.getItem(USERS_KEY);
  return raw ? (JSON.parse(raw) as Record<string, UserProfile>) : {};
};

const setUserMap = async (users: Record<string, UserProfile>) => {
  await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getActiveUser = async (): Promise<UserProfile | null> => {
  const raw = await AsyncStorage.getItem(ACTIVE_USER_KEY);
  return raw ? (JSON.parse(raw) as UserProfile) : null;
};

export const setActiveUser = async (user: UserProfile | null) => {
  if (!user) {
    await AsyncStorage.removeItem(ACTIVE_USER_KEY);
    return;
  }
  await AsyncStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(user));
};

export const findUser = async (email: string, password: string) => {
  const users = await getUserMap();
  const user = users[email.toLowerCase()];
  if (!user || user.password !== password) return null;
  return user;
};

export const createUser = async (payload: Omit<UserProfile, 'id'>) => {
  const users = await getUserMap();
  const emailKey = payload.email.toLowerCase();
  if (users[emailKey]) return null;
  const user: UserProfile = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    ...payload,
    email: payload.email.toLowerCase(),
  };
  users[emailKey] = user;
  await setUserMap(users);
  return user;
};

export const clearActiveUser = async () => {
  await AsyncStorage.removeItem(ACTIVE_USER_KEY);
};

const getSessionMap = async (): Promise<Record<string, SessionPayload>> => {
  const raw = await AsyncStorage.getItem(SESSIONS_KEY);
  return raw ? (JSON.parse(raw) as Record<string, SessionPayload>) : {};
};

const setSessionMap = async (payload: Record<string, SessionPayload>) => {
  await AsyncStorage.setItem(SESSIONS_KEY, JSON.stringify(payload));
};

export const getSessions = async (userId: string): Promise<SessionPayload> => {
  const map = await getSessionMap();
  return map[userId] || { sessions: [], activeSession: null };
};

export const setSessions = async (userId: string, payload: SessionPayload) => {
  const map = await getSessionMap();
  map[userId] = payload;
  await setSessionMap(map);
};

export const clearAll = async () => {
  await AsyncStorage.multiRemove([ACTIVE_USER_KEY, USERS_KEY, SESSIONS_KEY]);
};
