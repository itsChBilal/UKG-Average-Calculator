import { Session, ShiftType } from './types';

export type ShiftConfig = {
  durationMinutes: number;
  breaks: { start: string; end: string }[]; // HH:mm
};

export const SHIFT_CONFIG: Record<ShiftType, ShiftConfig> = {
  morning: {
    durationMinutes: 530, // 6:00 to 14:50
    breaks: [
      { start: '09:15', end: '09:30' },
      { start: '12:00', end: '12:30' },
    ],
  },
  afternoon: {
    durationMinutes: 530, // 13:10 to 22:00
    breaks: [
      { start: '17:30', end: '18:00' },
      { start: '20:15', end: '20:30' },
    ],
  },
};

const parseTimeOnDate = (date: Date, time: string) => {
  const [h, m] = time.split(':').map((v) => Number(v));
  const d = new Date(date);
  d.setHours(h, m, 0, 0);
  return d;
};

export const getBreakOverlapMinutes = (_start: Date, _end: Date, _shiftType: ShiftType) => 45;

export const getShiftStart = (now: Date, shiftType: ShiftType) => {
  if (shiftType === 'morning') {
    return parseTimeOnDate(now, '06:00');
  }
  return parseTimeOnDate(now, '13:10');
};

export const isBreakTime = (now: Date, start: Date, shiftType: ShiftType) => {
  const { breaks } = SHIFT_CONFIG[shiftType];
  return breaks.some((b) => {
    const bStart = parseTimeOnDate(start, b.start);
    const bEnd = parseTimeOnDate(start, b.end);
    return now >= bStart && now <= bEnd;
  });
};

export const getNextBreak = (now: Date, start: Date, shiftType: ShiftType) => {
  const { breaks } = SHIFT_CONFIG[shiftType];
  const upcoming = breaks
    .map((b) => ({
      start: parseTimeOnDate(start, b.start),
      end: parseTimeOnDate(start, b.end),
    }))
    .filter((b) => b.start.getTime() > now.getTime())
    .sort((a, b) => a.start.getTime() - b.start.getTime());

  return upcoming[0] || null;
};

export const getPlannedEnd = (start: Date, shiftType: ShiftType) => {
  const { durationMinutes } = SHIFT_CONFIG[shiftType];
  return new Date(start.getTime() + durationMinutes * 60000);
};

export const calculateAverage = (session: Session, now: Date) => {
  const start = new Date(session.startTime);
  const end = session.endTime ? new Date(session.endTime) : now;
  const totalQty = session.entries.reduce((sum, e) => sum + e.qty, 0);
  const totalMinutes = Math.max(0, (end.getTime() - start.getTime()) / 60000);
  const breakMinutes = getBreakOverlapMinutes(start, end, session.shiftType);
  const effectiveMinutes = Math.max(1, totalMinutes - breakMinutes);
  const avgPerHour = (totalQty / effectiveMinutes) * 60;
  return { totalQty, avgPerHour, effectiveMinutes, breakMinutes, totalMinutes };
};

export const formatTime = (date: Date) =>
  date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export const formatDuration = (minutes: number) => {
  const totalSeconds = Math.max(0, Math.floor(minutes * 60));
  const hours = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;
  const pad = (value: number) => value.toString().padStart(2, '0');
  return `${pad(hours)}:${pad(mins)}:${pad(secs)}`;
};

export const formatShortDate = (date: Date) =>
  date.toLocaleDateString([], { month: 'short', day: 'numeric' });
