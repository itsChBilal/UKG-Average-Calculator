export type ShiftType = 'morning' | 'afternoon';

export type SessionEntry = {
  id: string;
  qty: number;
  time: string; // ISO
};

export type Session = {
  id: string;
  line: string;
  targetAvg: number;
  startTime: string; // ISO
  endTime?: string; // ISO
  shiftType: ShiftType;
  entries: SessionEntry[];
};

export type UserProfile = {
  id: string;
  name: string;
  email: string;
  password: string;
};
