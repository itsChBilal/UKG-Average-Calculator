import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { getSessions, setSessions } from './storage';
import { Session, ShiftType } from './types';
import { getPlannedEnd, getShiftStart } from './sessionUtils';

export type SessionContextValue = {
  sessions: Session[];
  activeSession: Session | null;
  startSession: (payload: { line: string; targetAvg: number; shiftType: ShiftType }) => Promise<Session>;
  addEntry: (qty: number) => Promise<void>;
  removeEntry: (entryId: string) => Promise<void>;
  endSession: () => Promise<void>;
  refreshSessions: () => Promise<void>;
  setUserId: (id: string | null) => void;
  userId: string | null;
};

const SessionContext = createContext<SessionContextValue | undefined>(undefined);

const generateId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export const SessionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sessions, setSessionsState] = useState<Session[]>([]);
  const [activeSession, setActiveSessionState] = useState<Session | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  const load = async (id: string | null) => {
    if (!id) {
      setSessionsState([]);
      setActiveSessionState(null);
      return;
    }
    const { sessions: storedSessions, activeSession: storedActive } = await getSessions(id);
    setSessionsState(storedSessions);
    setActiveSessionState(storedActive);
  };

  useEffect(() => {
    load(userId);
  }, [userId]);

  const refreshSessions = async () => {
    await load(userId);
  };

  const startSession = async (payload: { line: string; targetAvg: number; shiftType: ShiftType }) => {
    if (!userId) throw new Error('No active user');
    const session: Session = {
      id: generateId(),
      line: payload.line,
      targetAvg: payload.targetAvg,
      shiftType: payload.shiftType,
      startTime: new Date().toISOString(),
      entries: [],
    };
    const nextPayload = { sessions, activeSession: session };
    setActiveSessionState(session);
    await setSessions(userId, nextPayload);
    return session;
  };

  const addEntry = async (qty: number) => {
    if (!activeSession || !userId) return;
    const updated: Session = {
      ...activeSession,
      entries: [
        { id: generateId(), qty, time: new Date().toISOString() },
        ...activeSession.entries,
      ],
    };
    setActiveSessionState(updated);
    await setSessions(userId, { sessions, activeSession: updated });
  };

  const removeEntry = async (entryId: string) => {
    if (!activeSession || !userId) return;
    const updated: Session = {
      ...activeSession,
      entries: activeSession.entries.filter((entry) => entry.id !== entryId),
    };
    setActiveSessionState(updated);
    await setSessions(userId, { sessions, activeSession: updated });
  };

  const endSession = async () => {
    if (!activeSession || !userId) return;
    const ended: Session = { ...activeSession, endTime: new Date().toISOString() };
    const updatedSessions = [ended, ...sessions];
    setSessionsState(updatedSessions);
    setActiveSessionState(null);
    await setSessions(userId, { sessions: updatedSessions, activeSession: null });
  };

  useEffect(() => {
    if (!activeSession) return;
    const interval = setInterval(async () => {
      const now = new Date();
      const shiftStart = getShiftStart(now, activeSession.shiftType);
      const plannedEnd = getPlannedEnd(shiftStart, activeSession.shiftType);
      if (now >= plannedEnd) {
        await endSession();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [activeSession, userId, sessions]);

  const value = useMemo(
    () => ({
      sessions,
      activeSession,
      startSession,
      addEntry,
      removeEntry,
      endSession,
      refreshSessions,
      setUserId,
      userId,
    }),
    [sessions, activeSession, userId]
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
};

export const useSession = () => {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error('useSession must be used inside SessionProvider');
  return ctx;
};
