import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { useColorScheme } from 'react-native';

export default function PrimaryButton({
  title,
  onPress,
  disabled = false,
}: {
  title: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  const scheme = useColorScheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: disabled
            ? scheme === 'dark'
              ? '#333'
              : '#ddd'
            : scheme === 'dark'
            ? '#6C8CFF'
            : '#2F5BFF',
          opacity: pressed ? 0.9 : 1,
        },
      ]}
    >
      <Text style={styles.text}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
});
