import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Session } from '../lib/types';
import { calculateAverage, formatShortDate } from '../lib/sessionUtils';
import Ionicons from '@expo/vector-icons/Ionicons';

const getColor = (percent: number) => {
  if (percent >= 100) return '#2ECC71';
  if (percent >= 80) return '#F39C12';
  return '#E74C3C';
};

export default function SessionTableRow({ session, onPress }: { session: Session; onPress: () => void }) {
  const { avgPerHour } = calculateAverage(session, new Date(session.endTime || session.startTime));
  const percent = (avgPerHour / session.targetAvg) * 100;
  const color = getColor(percent);

  return (
    <Pressable onPress={onPress} style={[styles.row, { borderLeftColor: color }]}> 
      <Text style={styles.cell}>{formatShortDate(new Date(session.startTime))}</Text>
      <Text style={styles.cell}>{session.line}</Text>
      <Text style={styles.cell}>{avgPerHour.toFixed(0)}</Text>
      <View style={styles.percentCell}>
        <Text style={[styles.cell, { color }]}>{percent.toFixed(0)}%</Text>
        <Ionicons name="chevron-forward" size={16} color="#9AA3B2" />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: '#F7F9FF',
    borderRadius: 12,
    borderLeftWidth: 4,
    marginBottom: 8,
  },
  cell: {
    flex: 1,
    fontSize: 13,
    color: '#2C2F3B',
    fontWeight: '600',
  },
  percentCell: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 6,
  },
});
