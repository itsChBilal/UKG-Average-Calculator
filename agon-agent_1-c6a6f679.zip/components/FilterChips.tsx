import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';

export default function FilterChips({
  options,
  selected,
  onSelect,
}: {
  options: string[];
  selected: string;
  onSelect: (value: string) => void;
}) {
  return (
    <View style={styles.container}>
      {options.map((option) => (
        <Pressable
          key={option}
          onPress={() => onSelect(option)}
          style={[styles.chip, selected === option && styles.selectedChip]}
        >
          <Text style={[styles.text, selected === option && styles.selectedText]}>{option}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  chip: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 999,
    backgroundColor: '#E7ECFF',
  },
  selectedChip: {
    backgroundColor: '#2F5BFF',
  },
  text: {
    color: '#2C2F3B',
    fontWeight: '600',
  },
  selectedText: {
    color: '#fff',
  },
});
