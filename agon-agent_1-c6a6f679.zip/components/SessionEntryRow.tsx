import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { SessionEntry } from '../lib/types';
import { formatTime } from '../lib/sessionUtils';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function SessionEntryRow({
  entry,
  onDelete,
  showDelete,
}: {
  entry: SessionEntry;
  onDelete?: () => void;
  showDelete?: boolean;
}) {
  return (
    <View style={styles.row}>
      <View>
        <Text style={styles.qty}>{entry.qty}</Text>
        <Text style={styles.time}>{formatTime(new Date(entry.time))}</Text>
      </View>
      {showDelete ? (
        <Pressable style={styles.deleteButton} onPress={onDelete}>
          <Ionicons name="trash" size={18} color="#fff" />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: '#151C2E',
    marginBottom: 10,
  },
  qty: {
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  time: {
    fontSize: 14,
    color: '#9AA3B2',
  },
  deleteButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#E74C3C',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
