import React, { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Session } from '../lib/types';
import { calculateAverage, formatShortDate, getPlannedEnd } from '../lib/sessionUtils';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import Ionicons from '@expo/vector-icons/Ionicons';

const getColor = (percent: number) => {
  if (percent >= 100) return '#2ECC71';
  if (percent >= 80) return '#F39C12';
  return '#E74C3C';
};

export default function ActiveSessionCard({ session, onPress }: { session: Session; onPress: () => void }) {
  const pulse = useSharedValue(1);

  useEffect(() => {
    pulse.value = withRepeat(withTiming(1.1, { duration: 1200 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  const { totalQty, avgPerHour } = calculateAverage(session, new Date());
  const end = getPlannedEnd(new Date(session.startTime), session.shiftType);
  const percent = (avgPerHour / session.targetAvg) * 100;
  const color = getColor(percent);

  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.row}>
        <View>
          <Text style={styles.title}>Active Session</Text>
          <Text style={styles.subtitle}>{session.line}</Text>
          <Text style={styles.meta}>{formatShortDate(new Date(session.startTime))}</Text>
        </View>
        <Animated.View style={[styles.pulse, animatedStyle]}>
          <Ionicons name="play" size={16} color="#fff" />
        </Animated.View>
      </View>
      <View style={styles.statsRow}>
        <Text style={styles.stat}>Total {totalQty}</Text>
        <Text style={styles.stat}>Avg/hr {avgPerHour.toFixed(0)}</Text>
        <Text style={[styles.stat, { color }]}>{percent.toFixed(0)}%</Text>
      </View>
      <Text style={styles.endsText}>Ends {end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 18,
    borderRadius: 20,
    backgroundColor: '#1A233B',
    marginBottom: 18,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    color: '#9FB2FF',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  subtitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '700',
  },
  meta: {
    color: '#A9B3C9',
    marginTop: 4,
  },
  pulse: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2F5BFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  stat: {
    color: '#D7DEF5',
    fontWeight: '600',
  },
  endsText: {
    color: '#A9B3C9',
    marginTop: 10,
  },
});
