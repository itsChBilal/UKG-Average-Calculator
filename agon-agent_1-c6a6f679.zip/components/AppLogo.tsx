import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function AppLogo({ size = 44 }: { size?: number }) {
  const iconSize = size * 0.5;
  return (
    <View style={[styles.container, { width: size, height: size, borderRadius: size * 0.3 }]}> 
      <View style={styles.inner}>
        <Ionicons name="speedometer" size={iconSize} color="#fff" />
        <Text style={styles.text}>UKG</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#2F5BFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#2F5BFF',
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 4,
  },
  inner: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
    marginTop: 2,
    letterSpacing: 1,
  },
});
