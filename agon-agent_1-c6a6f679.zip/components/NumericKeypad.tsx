import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useColorScheme } from 'react-native';

const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'back'];

export default function NumericKeypad({
  value,
  onChange,
  onDone,
  disabled,
}: {
  value: string;
  onChange: (next: string) => void;
  onDone: () => void;
  disabled?: boolean;
}) {
  const scheme = useColorScheme();
  return (
    <View style={styles.container}>
      <View style={styles.display}>
        <Text style={styles.displayText}>{value || '0'}</Text>
        <Pressable
          onPress={onDone}
          disabled={disabled || value.length === 0}
          style={({ pressed }) => [
            styles.doneButton,
            {
              backgroundColor: disabled || value.length === 0 ? '#999' : '#2F5BFF',
              opacity: pressed ? 0.9 : 1,
            },
          ]}
        >
          <Text style={styles.doneText}>Done</Text>
        </Pressable>
      </View>
      <View style={styles.grid}>
        {keys.map((key) => {
          return (
            <Pressable
              key={key}
              disabled={disabled}
              onPress={() => {
                if (key === 'clear') {
                  onChange('');
                  return;
                }
                if (key === 'back') {
                  onChange(value.slice(0, -1));
                  return;
                }
                onChange(value + key);
              }}
              style={({ pressed }) => [
                styles.key,
                {
                  backgroundColor: scheme === 'dark' ? '#1F2530' : '#F1F4FF',
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              {key === 'clear' ? (
                <Ionicons name="close-circle" size={22} color={scheme === 'dark' ? '#fff' : '#2F5BFF'} />
              ) : key === 'back' ? (
                <Ionicons name="backspace" size={22} color={scheme === 'dark' ? '#fff' : '#2F5BFF'} />
              ) : (
                <Text style={[styles.keyText, { color: scheme === 'dark' ? '#fff' : '#111827' }]}>
                  {key}
                </Text>
              )}
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 16,
  },
  display: {
    backgroundColor: '#0C1220',
    borderRadius: 18,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  displayText: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  doneButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  doneText: {
    color: '#fff',
    fontWeight: '700',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  key: {
    width: '30%',
    aspectRatio: 1.2,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyText: {
    fontSize: 20,
    fontWeight: '700',
  },
});
