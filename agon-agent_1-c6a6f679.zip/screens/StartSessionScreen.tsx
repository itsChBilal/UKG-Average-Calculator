import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Pressable } from 'react-native';
import { useSession } from '../lib/SessionContext';
import PrimaryButton from '../components/PrimaryButton';
import { ShiftType } from '../lib/types';

const presets = ['Tesco', 'Tesco Express', 'Tesco Ancillary', 'Morrisons', 'Asda'];
const shiftOptions: { label: string; value: ShiftType }[] = [
  { label: 'Morning (6:00-14:50)', value: 'morning' },
  { label: 'Afternoon (13:10-22:00)', value: 'afternoon' },
];

export default function StartSessionScreen({ navigation }: any) {
  const { startSession, activeSession } = useSession();
  const [line, setLine] = useState(presets[0]);
  const [custom, setCustom] = useState('');
  const [targetAvg, setTargetAvg] = useState('370');
  const [shiftType, setShiftType] = useState<ShiftType>('morning');

  const handleStart = async () => {
    if (activeSession) {
      navigation.navigate('Main', { screen: 'Session' });
      return;
    }
    const lineName = custom.trim() ? custom.trim() : line;
    await startSession({ line: lineName, targetAvg: Number(targetAvg), shiftType });
    navigation.navigate('Main', { screen: 'Session' });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Start New Session</Text>
      <Text style={styles.subtitle}>Choose your line and target average.</Text>
      <Text style={styles.sectionTitle}>Line Presets</Text>
      <View style={styles.chipRow}>
        {presets.map((option) => (
          <Pressable
            key={option}
            onPress={() => setLine(option)}
            style={[styles.chip, line === option && styles.chipSelected]}
          >
            <Text style={[styles.chipText, line === option && styles.chipTextSelected]}>{option}</Text>
          </Pressable>
        ))}
      </View>
      <View style={styles.field}>
        <Text style={styles.label}>Custom Line</Text>
        <TextInput
          value={custom}
          onChangeText={setCustom}
          placeholder="Add custom"
          placeholderTextColor="#9AA3B2"
          style={styles.input}
        />
      </View>
      <View style={styles.field}>
        <Text style={styles.label}>Target Average (per hour)</Text>
        <TextInput
          value={targetAvg}
          onChangeText={setTargetAvg}
          keyboardType="numeric"
          style={styles.input}
          returnKeyType="done"
        />
      </View>
      <Text style={styles.sectionTitle}>Shift Length</Text>
      <View style={styles.shiftRow}>
        {shiftOptions.map((option) => (
          <Pressable
            key={option.value}
            onPress={() => setShiftType(option.value)}
            style={[styles.shiftCard, shiftType === option.value && styles.shiftSelected]}
          >
            <Text style={styles.shiftLabel}>{option.label}</Text>
          </Pressable>
        ))}
      </View>
      <PrimaryButton title="Start Session" onPress={handleStart} disabled={!targetAvg} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F6FF',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#111827',
  },
  subtitle: {
    color: '#6A7280',
    marginBottom: 18,
  },
  sectionTitle: {
    fontWeight: '700',
    color: '#111827',
    marginTop: 12,
    marginBottom: 10,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  chip: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 16,
    backgroundColor: '#E6ECFF',
  },
  chipSelected: {
    backgroundColor: '#2F5BFF',
  },
  chipText: {
    fontWeight: '600',
    color: '#2C2F3B',
  },
  chipTextSelected: {
    color: '#fff',
  },
  field: {
    marginTop: 12,
    gap: 6,
  },
  label: {
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    color: '#9AA3B2',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  shiftRow: {
    gap: 10,
  },
  shiftCard: {
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E0E6F4',
  },
  shiftSelected: {
    borderColor: '#2F5BFF',
    backgroundColor: '#E6ECFF',
  },
  shiftLabel: {
    color: '#111827',
    fontWeight: '600',
  },
});
