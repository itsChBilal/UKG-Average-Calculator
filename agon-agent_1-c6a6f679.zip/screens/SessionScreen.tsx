import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, Modal } from 'react-native';
import { useSession } from '../lib/SessionContext';
import NumericKeypad from '../components/NumericKeypad';
import SessionEntryRow from '../components/SessionEntryRow';
import {
  calculateAverage,
  formatDuration,
  formatTime,
  getNextBreak,
  getPlannedEnd,
  getShiftStart,
  isBreakTime,
} from '../lib/sessionUtils';
import Ionicons from '@expo/vector-icons/Ionicons';
import Animated, { FadeInDown } from 'react-native-reanimated';

const getColor = (percent: number) => {
  if (percent >= 100) return '#2ECC71';
  if (percent >= 80) return '#F39C12';
  return '#E74C3C';
};

export default function SessionScreen({ navigation }: any) {
  const { activeSession, addEntry, endSession, removeEntry } = useSession();
  const [value, setValue] = useState('');
  const [showInfo, setShowInfo] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const session = activeSession;

  if (!session) {
    return (
      <View style={styles.container}>
        <Text style={styles.empty}>No active session.</Text>
      </View>
    );
  }

  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const { totalQty, avgPerHour, breakMinutes, totalMinutes } = calculateAverage(session, now);
  const percent = (avgPerHour / session.targetAvg) * 100;
  const color = getColor(percent);
  const start = new Date(session.startTime);
  const shiftStart = getShiftStart(now, session.shiftType);
  const end = getPlannedEnd(shiftStart, session.shiftType);
  const breakNow = isBreakTime(now, shiftStart, session.shiftType);
  const nextBreak = getNextBreak(now, shiftStart, session.shiftType);
  const entriesDisabled = breakNow;
  const minutesToNextBreak = nextBreak
    ? Math.max(0, (nextBreak.start.getTime() - now.getTime()) / 60000)
    : null;

  const handleDone = async () => {
    if (!value) return;
    await addEntry(Number(value));
    setValue('');
  };

  const handleEnd = async () => {
    await endSession();
    navigation.navigate('Home');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>{session.line}</Text>
          <Text style={styles.subtitle}>Started {formatTime(start)} · Ends {formatTime(end)}</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable style={styles.iconButton} onPress={() => setShowHistory(true)}>
            <Ionicons name="time" size={20} color="#fff" />
          </Pressable>
          <Pressable style={styles.iconButton} onPress={() => setShowInfo(true)}>
            <Ionicons name="information" size={20} color="#fff" />
          </Pressable>
          <Pressable style={styles.endButton} onPress={handleEnd}>
            <Ionicons name="power" size={20} color="#fff" />
          </Pressable>
        </View>
      </View>
      {breakNow && (
        <View style={styles.breakBanner}>
          <Text style={styles.breakText}>Break time — session paused for averages.</Text>
        </View>
      )}
      <View style={styles.metrics}>
        <View style={styles.metricCard}>
          <Text style={styles.metricLabel}>Total Picks</Text>
          <Text style={styles.metricValue}>{totalQty}</Text>
        </View>
        <View style={styles.metricCard}>
          <Text style={styles.metricLabel}>Avg/hr</Text>
          <Text style={styles.metricValue}>{avgPerHour.toFixed(0)}</Text>
        </View>
        <View style={[styles.metricCard, { borderColor: color }]}> 
          <Text style={[styles.metricLabel, { color }]}>Performance</Text>
          <Text style={[styles.metricValue, { color }]}>{percent.toFixed(0)}%</Text>
        </View>
      </View>
      <View style={styles.breakInfoRow}>
        <Ionicons name="alarm" size={16} color="#9AA3B2" />
        <Text style={styles.breakInfoText}>
          {minutesToNextBreak !== null
            ? `Next break in ${formatDuration(minutesToNextBreak)}`
            : 'No more breaks scheduled'}
        </Text>
      </View>
      <NumericKeypad value={value} onChange={setValue} onDone={handleDone} disabled={entriesDisabled} />
      <Modal visible={showInfo} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Session Insights</Text>
            <Text style={styles.modalText}>Started at {formatTime(start)}</Text>
            <Text style={styles.modalText}>Shift end {formatTime(end)}</Text>
            <Text style={styles.modalText}>Breaks excluded: {breakMinutes} min</Text>
            <Text style={styles.modalText}>Active work minutes: {Math.max(0, Math.round(totalMinutes - breakMinutes))}</Text>
            <Text style={styles.modalText}>
              {minutesToNextBreak !== null
                ? `Next break in ${formatDuration(minutesToNextBreak)}`
                : 'No upcoming breaks'}
            </Text>
            <Pressable style={styles.modalButton} onPress={() => setShowInfo(false)}>
              <Text style={styles.modalButtonText}>Got it</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
      <Modal visible={showHistory} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCardLarge}>
            <View style={styles.modalHeaderRow}>
              <Text style={styles.modalTitle}>Recent Orders</Text>
              <Pressable onPress={() => setShowHistory(false)}>
                <Ionicons name="close" size={20} color="#fff" />
              </Pressable>
            </View>
            <FlatList
              data={session.entries}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <SessionEntryRow
                  entry={item}
                  showDelete
                  onDelete={() => removeEntry(item.id)}
                />
              )}
              ListEmptyComponent={<Text style={styles.empty}>No picks logged yet.</Text>}
              showsVerticalScrollIndicator={false}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0E1322',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: '#fff',
  },
  subtitle: {
    color: '#C5CDE0',
    marginTop: 4,
  },
  iconButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#1F2740',
    alignItems: 'center',
    justifyContent: 'center',
  },
  endButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#E74C3C',
    alignItems: 'center',
    justifyContent: 'center',
  },
  breakBanner: {
    marginTop: 16,
    backgroundColor: '#2C3A58',
    borderRadius: 14,
    padding: 12,
  },
  breakText: {
    color: '#FFD27D',
    fontWeight: '600',
  },
  metrics: {
    flexDirection: 'row',
    gap: 10,
    marginVertical: 18,
  },
  metricCard: {
    flex: 1,
    backgroundColor: '#151C2E',
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: '#1F2740',
  },
  metricLabel: {
    color: '#9AA3B2',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  metricValue: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '800',
    marginTop: 8,
  },
  breakInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  breakInfoText: {
    color: '#9AA3B2',
  },
  listTitle: {
    color: '#C5CDE0',
    marginTop: 20,
    marginBottom: 10,
    fontWeight: '600',
  },
  empty: {
    color: '#9AA3B2',
    textAlign: 'center',
    marginTop: 20,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10, 14, 24, 0.8)',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: '#1B2238',
    borderRadius: 18,
    padding: 20,
    gap: 10,
  },
  modalCardLarge: {
    backgroundColor: '#1B2238',
    borderRadius: 18,
    padding: 20,
    gap: 12,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  modalText: {
    color: '#C5CDE0',
  },
  modalButton: {
    marginTop: 10,
    backgroundColor: '#2F5BFF',
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#fff',
    fontWeight: '700',
  },
  modalHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
