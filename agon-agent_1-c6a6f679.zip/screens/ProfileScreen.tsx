import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useSession } from '../lib/SessionContext';
import { clearActiveUser } from '../lib/storage';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function ProfileScreen({ onLogout }: { onLogout: () => void }) {
  const { activeSession, sessions } = useSession();

  const handleLogout = async () => {
    await clearActiveUser();
    onLogout();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <View style={styles.card}>
        <View style={styles.row}>
          <Ionicons name="person" size={20} color="#2F5BFF" />
          <Text style={styles.cardText}>Profile stored on device</Text>
        </View>
        <View style={styles.row}>
          <Ionicons name="time" size={20} color="#2F5BFF" />
          <Text style={styles.cardText}>Sessions: {sessions.length}</Text>
        </View>
        {activeSession && (
          <View style={styles.row}>
            <Ionicons name="pulse" size={20} color="#2F5BFF" />
            <Text style={styles.cardText}>Active: {activeSession.line}</Text>
          </View>
        )}
      </View>
      <Pressable style={styles.logout} onPress={handleLogout}>
        <Ionicons name="log-out" size={20} color="#fff" />
        <Text style={styles.logoutText}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F6FF',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#111827',
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    gap: 12,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  cardText: {
    fontWeight: '600',
    color: '#2C2F3B',
  },
  logout: {
    marginTop: 24,
    backgroundColor: '#E74C3C',
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'center',
  },
  logoutText: {
    color: '#fff',
    fontWeight: '700',
  },
});
