import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import PrimaryButton from '../components/PrimaryButton';
import AppLogo from '../components/AppLogo';
import { createUser, findUser, setActiveUser } from '../lib/storage';

export default function LoginScreen({ onComplete }: { onComplete: () => void }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleContinue = async () => {
    setError('');
    if (!email.trim() || !password.trim()) {
      setError('Email and password are required.');
      return;
    }

    const existing = await findUser(email.trim(), password.trim());
    if (existing) {
      await setActiveUser(existing);
      onComplete();
      return;
    }

    if (!name.trim()) {
      setError('New users need a full name.');
      return;
    }

    const created = await createUser({
      name: name.trim(),
      email: email.trim(),
      password: password.trim(),
    });

    if (!created) {
      setError('Account already exists. Check your password.');
      return;
    }

    await setActiveUser(created);
    onComplete();
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.container}>
      <View style={styles.card}>
        <View style={styles.logoRow}>
          <AppLogo size={56} />
          <View>
            <Text style={styles.title}>UKG Average Calculator</Text>
            <Text style={styles.subtitle}>Log in with email + password or create a new account.</Text>
          </View>
        </View>
        {error ? <Text style={styles.error}>{error}</Text> : null}
        <View style={styles.field}>
          <Text style={styles.label}>Full Name (new users)</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="John Doe"
            placeholderTextColor="#9BA4B5"
            style={styles.input}
            returnKeyType="next"
          />
        </View>
        <View style={styles.field}>
          <Text style={styles.label}>Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            placeholderTextColor="#9BA4B5"
            style={styles.input}
            keyboardType="email-address"
            autoCapitalize="none"
            returnKeyType="next"
          />
        </View>
        <View style={styles.field}>
          <Text style={styles.label}>Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Enter password"
            placeholderTextColor="#9BA4B5"
            style={styles.input}
            secureTextEntry
            returnKeyType="done"
          />
        </View>
        <PrimaryButton
          title="Continue"
          onPress={handleContinue}
          disabled={!email.trim() || !password.trim()}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0E1322',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: '#1B2238',
    padding: 24,
    borderRadius: 20,
    gap: 16,
  },
  error: {
    color: '#FF8A8A',
    fontWeight: '600',
  },
  logoRow: {
    flexDirection: 'row',
    gap: 14,
    alignItems: 'center',
  },
  title: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '700',
  },
  subtitle: {
    color: '#C5CDE0',
    fontSize: 13,
    marginTop: 4,
  },
  field: {
    gap: 8,
  },
  label: {
    color: '#9FB2FF',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  input: {
    backgroundColor: '#111828',
    color: '#fff',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
});
