import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, Modal } from 'react-native';
import { useSession } from '../lib/SessionContext';
import ActiveSessionCard from '../components/ActiveSessionCard';
import SessionTableRow from '../components/SessionTableRow';
import FilterChips from '../components/FilterChips';
import Ionicons from '@expo/vector-icons/Ionicons';
import Animated, { FadeInDown, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { calculateAverage, formatTime, formatShortDate } from '../lib/sessionUtils';
import SessionEntryRow from '../components/SessionEntryRow';

export default function HomeScreen({ navigation }: any) {
  const { sessions, activeSession, refreshSessions } = useSession();
  const [filter, setFilter] = useState('All');
  const [refreshing, setRefreshing] = useState(false);
  const [selectedSession, setSelectedSession] = useState<typeof sessions[0] | null>(null);
  const pulse = useSharedValue(1);

  useEffect(() => {
    pulse.value = withRepeat(withTiming(1.1, { duration: 1200 }), -1, true);
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  const lines = useMemo(() => {
    const unique = Array.from(new Set(sessions.map((s) => s.line)));
    return ['All', ...unique];
  }, [sessions]);

  const filteredSessions = sessions.filter((s) => (filter === 'All' ? true : s.line === filter));

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshSessions();
    setRefreshing(false);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={filteredSessions}
        keyExtractor={(item) => item.id}
        refreshing={refreshing}
        onRefresh={onRefresh}
        ListHeaderComponent={
          <View>
            <Text style={styles.greeting}>Today</Text>
            <Text style={styles.title}>Shift Overview</Text>
            {activeSession ? (
              <ActiveSessionCard session={activeSession} onPress={() => navigation.navigate('Session')} />
            ) : (
              <View style={styles.noSession}>
                <Text style={styles.noSessionText}>No active session. Start one with the + button.</Text>
              </View>
            )}
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>History</Text>
              <Text style={styles.sectionMeta}>{filteredSessions.length} sessions</Text>
            </View>
            <FilterChips options={lines} selected={filter} onSelect={setFilter} />
            <View style={styles.tableHeader}>
              <Text style={styles.headerCell}>Date</Text>
              <Text style={styles.headerCell}>Line</Text>
              <Text style={styles.headerCell}>Avg/hr</Text>
              <Text style={styles.headerCell}>%</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Animated.View entering={FadeInDown.duration(200)}>
            <SessionTableRow session={item} onPress={() => setSelectedSession(item)} />
          </Animated.View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No sessions yet.</Text>}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
      <Animated.View style={[styles.fab, pulseStyle]}>
        <Pressable onPress={() => navigation.navigate('StartSession')} style={styles.fabPressable}>
          <Ionicons name="add" size={28} color="#fff" />
        </Pressable>
      </Animated.View>
      <Modal visible={!!selectedSession} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            {selectedSession && (
              <>
                <View style={styles.modalHeader}>
                  <View>
                    <Text style={styles.modalTitle}>{selectedSession.line}</Text>
                    <Text style={styles.modalSubtitle}>{formatShortDate(new Date(selectedSession.startTime))}</Text>
                  </View>
                  <Pressable onPress={() => setSelectedSession(null)}>
                    <Ionicons name="close" size={20} color="#fff" />
                  </Pressable>
                </View>
                <View style={styles.modalStats}>
                  <Text style={styles.modalStatText}>Started: {formatTime(new Date(selectedSession.startTime))}</Text>
                  <Text style={styles.modalStatText}>
                    Ended: {selectedSession.endTime ? formatTime(new Date(selectedSession.endTime)) : 'Active'}
                  </Text>
                  <Text style={styles.modalStatText}>Target: {selectedSession.targetAvg}/hr</Text>
                  <Text style={styles.modalStatText}>
                    Avg/hr: {calculateAverage(selectedSession, new Date(selectedSession.endTime || selectedSession.startTime)).avgPerHour.toFixed(0)}
                  </Text>
                  <Text style={styles.modalStatText}>Total entries: {selectedSession.entries.length}</Text>
                </View>
                <Text style={styles.modalSection}>Entries</Text>
                <FlatList
                  data={selectedSession.entries}
                  keyExtractor={(item) => item.id}
                  renderItem={({ item }) => <SessionEntryRow entry={item} />}
                  ListEmptyComponent={<Text style={styles.modalEmpty}>No entries logged.</Text>}
                  showsVerticalScrollIndicator={false}
                />
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F6FF',
  },
  listContent: {
    padding: 20,
    paddingBottom: 120,
  },
  greeting: {
    fontSize: 14,
    color: '#6A7280',
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: '#111827',
    marginBottom: 16,
  },
  noSession: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 18,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  noSessionText: {
    color: '#6A7280',
  },
  sectionHeader: {
    marginTop: 18,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  sectionMeta: {
    color: '#6A7280',
  },
  tableHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
    marginBottom: 8,
  },
  headerCell: {
    flex: 1,
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    color: '#9AA3B2',
    fontWeight: '600',
  },
  empty: {
    padding: 20,
    textAlign: 'center',
    color: '#9AA3B2',
  },
  fab: {
    position: 'absolute',
    right: 24,
    bottom: 28,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#2F5BFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#2F5BFF',
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 6,
  },
  fabPressable: {
    width: 60,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(12, 16, 28, 0.85)',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: '#1B2238',
    borderRadius: 18,
    padding: 20,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  modalSubtitle: {
    color: '#9AA3B2',
    marginTop: 2,
  },
  modalStats: {
    gap: 6,
    marginBottom: 12,
  },
  modalStatText: {
    color: '#C5CDE0',
  },
  modalSection: {
    color: '#9FB2FF',
    fontWeight: '700',
    marginBottom: 8,
  },
  modalEmpty: {
    color: '#9AA3B2',
    textAlign: 'center',
    marginTop: 20,
  },
});
