import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import StartSessionScreen from './screens/StartSessionScreen';
import SessionScreen from './screens/SessionScreen';
import ProfileScreen from './screens/ProfileScreen';
import { SessionProvider, useSession } from './lib/SessionContext';
import { getActiveUser } from './lib/storage';
import { View } from 'react-native';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs({ onLogout }: { onLogout: () => void }) {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: true,
        headerStyle: { backgroundColor: '#0E1322' },
        headerTintColor: '#fff',
        tabBarStyle: { backgroundColor: '#0E1322', borderTopColor: '#1E2538' },
        tabBarActiveTintColor: '#6C8CFF',
        tabBarInactiveTintColor: '#66718F',
        tabBarIcon: ({ color, size }) => {
          const iconMap: Record<string, keyof typeof Ionicons.glyphMap> = {
            Home: 'home',
            Session: 'pulse',
            Profile: 'person',
          };
          const name = iconMap[route.name] || 'ellipse';
          return <Ionicons name={name} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: 'Overview' }} />
      <Tab.Screen name="Session" component={SessionScreen} options={{ title: 'Active Session' }} />
      <Tab.Screen name="Profile" options={{ title: 'Settings' }}>
        {() => <ProfileScreen onLogout={onLogout} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
}

function AppContent() {
  const { setUserId } = useSession();
  const [isAuthed, setIsAuthed] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const load = async () => {
      const user = await getActiveUser();
      if (user) {
        setUserId(user.id);
        setIsAuthed(true);
      }
      setChecked(true);
    };
    load();
  }, []);

  const handleLogin = async () => {
    const user = await getActiveUser();
    if (!user) return;
    setUserId(user.id);
    setIsAuthed(true);
  };

  const handleLogout = () => {
    setUserId(null);
    setIsAuthed(false);
  };

  if (!checked) {
    return <View style={{ flex: 1, backgroundColor: '#0E1322' }} />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: true,
          headerStyle: { backgroundColor: '#0E1322' },
          headerTintColor: '#fff',
        }}
      >
        {!isAuthed ? (
          <Stack.Screen name="Login" options={{ headerShown: false }}>
            {() => <LoginScreen onComplete={handleLogin} />}
          </Stack.Screen>
        ) : (
          <>
            <Stack.Screen name="Main" options={{ headerShown: false }}>
              {() => <MainTabs onLogout={handleLogout} />}
            </Stack.Screen>
            <Stack.Screen name="StartSession" component={StartSessionScreen} options={{ title: 'Start Session' }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });

  if (!fontsLoaded) {
    return <View style={{ flex: 1, backgroundColor: '#0E1322' }} />;
  }

  return (
    <SafeAreaProvider>
      <SessionProvider>
        <AppContent />
        <StatusBar style="light" />
      </SessionProvider>
    </SafeAreaProvider>
  );
}
